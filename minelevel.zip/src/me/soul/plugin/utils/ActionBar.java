package me.soul.plugin.utils;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import me.soul.plugin.Main;
import me.soul.plugin.User;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.ComponentBuilder;

public class ActionBar extends BukkitRunnable{
	
	private Plugin main;
	
	public ActionBar(Plugin main)
	{
		this.setMain(main);
	}
	
	public void run()
	{
		for(Player op : Bukkit.getOnlinePlayers())
		{
			User user = Main.getUsersUtils().getUser(op.getUniqueId());
			if(user.hasPickaxeEquipped())
				user.getPlayer().spigot().sendMessage(ChatMessageType.ACTION_BAR, new ComponentBuilder("§7§l» " + 
			            (user.getNextLevelPercentage() >= 10 ? "§a■" : "§c■") + 
						(user.getNextLevelPercentage() >= 20 ? "§a■" : "§c■") + 
						(user.getNextLevelPercentage() >= 30 ? "§a■" : "§c■") + 
						(user.getNextLevelPercentage() >= 40 ? "§a■" : "§c■") + 
						(user.getNextLevelPercentage() >= 50 ? "§a■" : "§c■") + 
						(user.getNextLevelPercentage() >= 60 ? "§a■" : "§c■") + 
						(user.getNextLevelPercentage() >= 70 ? "§a■" : "§c■") + 
						(user.getNextLevelPercentage() >= 80 ? "§a■" : "§c■") + 
						(user.getNextLevelPercentage() >= 90 ? "§a■" : "§c■") + 
						(user.getNextLevelPercentage() >= 100 ? "§a■" : "§c■") + " §7| §3" + user.getNextLevelPercentage() + "§b% §7§l«").create());
		}
	}

	public Plugin getMain()
	{
		return main;
	}

	public void setMain(Plugin main)
	{
		this.main = main;
	}

}

package me.soul.plugin.events;

import me.soul.plugin.Main;
import me.soul.plugin.User;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class LeftListener implements Listener{

	/**
	 * Quit event listener created on 04/01/2018
	 * @param event
	 */
	@EventHandler
	public void onLeft(PlayerQuitEvent event)
	{
		Player player = event.getPlayer();
		User user = Main.getUsersUtils().getUser(player.getUniqueId());
		Main.getDatabaseManager().saveUserLevel(user);
		Main.getDatabaseManager().saveUserBlocks(user);
		Main.getUsersUtils().removeUser(user);
	}
}

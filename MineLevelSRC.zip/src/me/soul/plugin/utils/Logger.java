package me.soul.plugin.utils;

import org.bukkit.entity.Player;

public class Logger {

	public static void log(Player player, String message)
	{
		player.sendMessage("�6�lM�eine�3�lL�bevel �8� " + message);
	}
}

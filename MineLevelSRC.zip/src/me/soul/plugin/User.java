package me.soul.plugin;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class User {
	
	private UUID user;
	private int level;
	
	/**
	 * User class created on 04/01/2018
	 * @param user
	 * @param level
	 */
	public User(UUID user, int level)
	{
		this.setUser(user);
		this.setLevel(level);
	}

	/**
	 * Check for the requirements to break the block created on 04/01/2018
	 * @param block
	 * @return
	 */
	public boolean canBreak(Block block)
	{
		if(this.getLevel() < 5)
		{
			if(!this.hasPickaxeEquipped())
				if(block.getType().equals(Material.COAL_ORE))
					return true;
		}
		if(this.getLevel() < 10)
		{
			if(this.hasPickaxeEquipped() && this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE))
			{
				if(block.getType().equals(Material.COAL_ORE))
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped())
					if(block.getType().equals(Material.COAL_ORE))
						return true;
			}		
		}
		if(this.getLevel() < 15)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE)))
			{
				if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE))
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped())
					if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE))
						return true;
			}
		}
		if(this.getLevel() < 20)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE)))
			{
				if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE))
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped())
					if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE))
						return true;
			}
		}
		if(this.getLevel() < 25)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE)))
			{
				if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE))
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped())
					if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE))
						return true;
			}
		}
		if(this.getLevel() < 30)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.IRON_PICKAXE)))
			{
				if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE))
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped())
					if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE))
						return true;
			}
		}
		if(this.getLevel() < 35)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.IRON_PICKAXE)))
			{
				if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE))
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped())
					if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE))
						return true;
			}
		}
		if(this.getLevel() < 40)
		{
			if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE))
				return true;
		}
		if(this.getLevel() < 45)
		{
			if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE) || block.getType().equals(Material.GOLD_ORE))
				return true;
		}
		if(this.getLevel() < 50)
		{
			if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE) || block.getType().equals(Material.GOLD_ORE)  || block.getType().equals(Material.EMERALD_ORE))
				return true;
		}
		if(this.getLevel() >= 50)
			return true;
		return false;
	}
	
	public boolean hasPickaxeEquipped()
	{
		return this.getPlayer().getItemInHand() != null &&
				(this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.IRON_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.GOLD_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.DIAMOND_PICKAXE));
	}
	
	public Player getPlayer()
	{
		return Bukkit.getPlayer(this.getUser());
	}
	public UUID getUser()
	{
		return user;
	}
	public void setUser(UUID user)
	{
		this.user = user;
	}
	public int getLevel()
	{
		return level;
	}
	public void setLevel(int level)
	{
		this.level = level;
	}
}

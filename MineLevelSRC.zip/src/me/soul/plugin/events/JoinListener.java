package me.soul.plugin.events;

import me.soul.plugin.Main;
import me.soul.plugin.User;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinListener implements Listener{

	/**
	 * First join event listener created on 04/01/2018
	 * @param event
	 */
	@EventHandler
	public void onFirstJoin(PlayerJoinEvent event)
	{
		Player player = event.getPlayer();
		if(!player.hasPlayedBefore())
			Main.getDatabaseManager().registerNewUser(player.getUniqueId());
	}
	
	/**
	 * Join event listener created on 04/01/2018
	 * @param event
	 */
	@EventHandler
	public void onJoin(PlayerJoinEvent event)
	{
		Player player = event.getPlayer();
		User user = new User(player.getUniqueId(), Main.getDatabaseManager().getUserLevel(player.getUniqueId()));
		Main.getUsersUtils().addUser(user);
	}
}

package me.soul.plugin;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class User {
	
	private UUID user;
	private int level;
	private int blocks;
	
	/**
	 * User class created on 04/01/2018
	 * @param user
	 * @param level
	 */
	public User(UUID user, int level, int blocks)
	{
		this.setUser(user);
		this.setLevel(level);
		this.setBlocks(blocks);
	}

	/**
	 * Check for the requirements to break the block created on 04/01/2018
	 * @param block
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public boolean canBreak(Block block)
	{
		if(!block.getType().equals(Material.COAL_ORE) && !block.getType().equals(Material.REDSTONE_ORE) && !block.getType().equals(Material.LAPIS_ORE) && !block.getType().equals(Material.IRON_ORE) && !block.getType().equals(Material.GOLD_ORE)  && !block.getType().equals(Material.DIAMOND_ORE) && !block.getType().equals(Material.EMERALD_ORE))
			return true;
		if(this.getLevel() < 5)
		{
			if(!this.hasPickaxeEquipped())
				if(block.getType().equals(Material.COAL_ORE))
					return true;
		}
		if(this.getLevel() < 10)
		{
			if(this.hasPickaxeEquipped() && this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) && block.getType().equals(Material.COAL_ORE))
					return true;
			else
				if(!this.hasPickaxeEquipped() && block.getType().equals(Material.COAL_ORE))
					return true;
				else
					return false;
		}
		if(this.getLevel() < 15)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 20)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 25)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 30)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.IRON_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 35)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.IRON_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 40)
		{
			if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE))
				return true;
			else
				return false;
		}
		if(this.getLevel() < 45)
		{
			if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE) || block.getType().equals(Material.GOLD_ORE))
				return true;
			else
				return false;
		}
		if(this.getLevel() < 50)
		{
			if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE) || block.getType().equals(Material.GOLD_ORE)  || block.getType().equals(Material.DIAMOND_ORE))
				return true;
			else
				return false;
		}
		if(this.getLevel() >= 50)
			return true;
		return false;
	}
	
	@SuppressWarnings("deprecation")
	public void checkForLevelUp()
	{
		switch(this.getBlocks())
		{
		case 100:
			this.setLevel(2);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b200�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 300:
			this.setLevel(3);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b200�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 500:
			this.setLevel(4);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 1000:
			this.setLevel(5);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b300�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 1300:
			this.setLevel(6);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b300�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 1600:
			this.setLevel(7);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b300�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 1900:
			this.setLevel(8);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b300�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 2200:
			this.setLevel(9);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 2700:
			this.setLevel(10);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 3200:
			this.setLevel(11);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 3700:
			this.setLevel(12);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 4200:
			this.setLevel(13);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 4700:
			this.setLevel(14);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b1000�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 5700:
			this.setLevel(15);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 6200:
			this.setLevel(16);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 6700:
			this.setLevel(17);
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 7200:
			this.setLevel(18);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 7700:
			this.setLevel(19);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b1000�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 8700:
			this.setLevel(20);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 9200:
			this.setLevel(21);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 9700:
			this.setLevel(22);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 10200:
			this.setLevel(23);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 10700:
			this.setLevel(24);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b2000�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 12700:
			this.setLevel(25);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 13200:
			this.setLevel(26);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 13700:
			this.setLevel(27);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 14200:
			this.setLevel(28);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 14700:
			this.setLevel(29);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b2000�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 16700:
			this.setLevel(30);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 17200:
			this.setLevel(31);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 17700:
			this.setLevel(32);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 18200:
			this.setLevel(33);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 18700:
			this.setLevel(34);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b3000�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 21700:
			this.setLevel(35);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 22200:
			this.setLevel(36);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 22700:
			this.setLevel(37);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 23200:
			this.setLevel(38);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 23700:
			this.setLevel(39);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b4000�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 27700:
			this.setLevel(40);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 28200:
			this.setLevel(41);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 28700:
			this.setLevel(42);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 29200:
			this.setLevel(43);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 29700:
			this.setLevel(44);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b5000�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 34700:
			this.setLevel(45);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 35200:
			this.setLevel(46);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 35700:
			this.setLevel(47);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 36200:
			this.setLevel(48);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b500�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 36700:
			this.setLevel(49);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�7Per raggiungere il prossimo livello spacca �b10000�7 blocchi!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 46700:
			this.setLevel(50);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() 
			{
				public void run()
				{
					getPlayer().sendTitle("�3�lL�bivello", "�bCongratulazioni�7! Hai raggiunto l'ultimo livello disponibile!");
				}
			}, 60);
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		}
	}
	
	public int getBlocksToNextLevel()
	{
		int levelBlocks = 0;
		switch(this.getLevel())
		{
		case 1:
			levelBlocks = 100;
			break;
		case 2:
			levelBlocks = 300;
			break;
		case 3:
			levelBlocks = 500;
			break;
		case 4:
			levelBlocks = 1000;
			break;
		case 5:
			levelBlocks = 1300;
			break;
		case 6:
			levelBlocks = 1600;
			break;
		case 7:
			levelBlocks = 1900;
			break;
		case 8:
			levelBlocks = 2200;
			break;
		case 9:
			levelBlocks = 2700;
			break;
		case 10:
			levelBlocks = 3200;
			break;
		case 11:
			levelBlocks = 3700;
			break;
		case 12:
			levelBlocks = 4200;
			break;
		case 13:
			levelBlocks = 4700;
			break;
		case 14:
			levelBlocks = 5700;
			break;
		case 15:
			levelBlocks = 6200;
			break;
		case 16:
			levelBlocks = 6700;
			break;
		case 17:
			levelBlocks = 7200;
			break;
		case 18:
			levelBlocks = 7700;
			break;
		case 19:
			levelBlocks = 8700;
			break;
		case 20:
			levelBlocks = 9200;
			break;
		case 21:
			levelBlocks = 9700;
			break;
		case 22:
			levelBlocks = 10200;
			break;
		case 23:
			levelBlocks = 10700;
			break;
		case 24:
			levelBlocks = 12700;
			break;
		case 25:
			levelBlocks = 13200;
			break;
		case 26:
			levelBlocks = 13700;
			break;
		case 27:
			levelBlocks = 14200;
			break;
		case 28:
			levelBlocks = 14700;
			break;
		case 29:
			levelBlocks = 16700;
			break;
		case 30:
			levelBlocks = 17200;
			break;
		case 31:
			levelBlocks = 17700;
			break;
		case 32:
			levelBlocks = 18200;
			break;
		case 33:
			levelBlocks = 18700;
			break;
		case 34:
			levelBlocks = 21700;
			break;
		case 35:
			levelBlocks = 22200;
			break;
		case 36:
			levelBlocks = 22700;
			break;
		case 37:
			levelBlocks = 23200;
			break;
		case 38:
			levelBlocks = 23700;
			break;
		case 39:
			levelBlocks = 27700;
			break;
		case 40:
			levelBlocks = 28200;
			break;
		case 41:
			levelBlocks = 28700;
			break;
		case 42:
			levelBlocks = 29200;
			break;
		case 43:
			levelBlocks = 29700;
			break;
		case 44:
			levelBlocks = 34700;
			break;
		case 45:
			levelBlocks = 35200;
			break;
		case 46:
			levelBlocks = 35700;
			break;
		case 47:
			levelBlocks = 36200;
			break;
		case 48:
			levelBlocks = 36700;
			break;
		case 49:
			levelBlocks = 46700;
			break;
		}
		return levelBlocks - this.getBlocks();
	}
	
	public int getNextLevelPercentage()
	{
		int levelBlocks = 0;
		switch(this.getLevel())
		{
		case 1:
			levelBlocks = 100;
			break;
		case 2:
			levelBlocks = 300;
			break;
		case 3:
			levelBlocks = 500;
			break;
		case 4:
			levelBlocks = 1000;
			break;
		case 5:
			levelBlocks = 1300;
			break;
		case 6:
			levelBlocks = 1600;
			break;
		case 7:
			levelBlocks = 1900;
			break;
		case 8:
			levelBlocks = 2200;
			break;
		case 9:
			levelBlocks = 2700;
			break;
		case 10:
			levelBlocks = 3200;
			break;
		case 11:
			levelBlocks = 3700;
			break;
		case 12:
			levelBlocks = 4200;
			break;
		case 13:
			levelBlocks = 4700;
			break;
		case 14:
			levelBlocks = 5700;
			break;
		case 15:
			levelBlocks = 6200;
			break;
		case 16:
			levelBlocks = 6700;
			break;
		case 17:
			levelBlocks = 7200;
			break;
		case 18:
			levelBlocks = 7700;
			break;
		case 19:
			levelBlocks = 8700;
			break;
		case 20:
			levelBlocks = 9200;
			break;
		case 21:
			levelBlocks = 9700;
			break;
		case 22:
			levelBlocks = 10200;
			break;
		case 23:
			levelBlocks = 10700;
			break;
		case 24:
			levelBlocks = 12700;
			break;
		case 25:
			levelBlocks = 13200;
			break;
		case 26:
			levelBlocks = 13700;
			break;
		case 27:
			levelBlocks = 14200;
			break;
		case 28:
			levelBlocks = 14700;
			break;
		case 29:
			levelBlocks = 16700;
			break;
		case 30:
			levelBlocks = 17200;
			break;
		case 31:
			levelBlocks = 17700;
			break;
		case 32:
			levelBlocks = 18200;
			break;
		case 33:
			levelBlocks = 18700;
			break;
		case 34:
			levelBlocks = 21700;
			break;
		case 35:
			levelBlocks = 22200;
			break;
		case 36:
			levelBlocks = 22700;
			break;
		case 37:
			levelBlocks = 23200;
			break;
		case 38:
			levelBlocks = 23700;
			break;
		case 39:
			levelBlocks = 27700;
			break;
		case 40:
			levelBlocks = 28200;
			break;
		case 41:
			levelBlocks = 28700;
			break;
		case 42:
			levelBlocks = 29200;
			break;
		case 43:
			levelBlocks = 29700;
			break;
		case 44:
			levelBlocks = 34700;
			break;
		case 45:
			levelBlocks = 35200;
			break;
		case 46:
			levelBlocks = 35700;
			break;
		case 47:
			levelBlocks = 36200;
			break;
		case 48:
			levelBlocks = 36700;
			break;
		case 49:
			levelBlocks = 46700;
			break;
		}
		return this.getBlocksToNextLevel() * 5 / this.getBlocks();
	}
	
	@SuppressWarnings("deprecation")
	public boolean hasPickaxeEquipped()
	{
		return this.getPlayer().getItemInHand() != null &&
				(this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.IRON_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.GOLD_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.DIAMOND_PICKAXE));
	}
	
	public Player getPlayer()
	{
		return Bukkit.getPlayer(this.getUser());
	}
	public UUID getUser()
	{
		return user;
	}
	public void setUser(UUID user)
	{
		this.user = user;
	}
	public int getLevel()
	{
		return level;
	}
	public void setLevel(int level)
	{
		this.level = level;
	}

	public int getBlocks() {
		return blocks;
	}

	public void setBlocks(int blocks) {
		this.blocks = blocks;
	}
}

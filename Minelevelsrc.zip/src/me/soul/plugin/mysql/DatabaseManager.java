package me.soul.plugin.mysql;

import java.sql.ResultSet;
import java.util.UUID;

import me.soul.plugin.Main;
import me.soul.plugin.User;

public class DatabaseManager {

	/**
	 * User existance check method crated on 21/01/2018
	 * @param uuid
	 * @return
	 */
	public boolean existUser(UUID uuid)
	{
		try
		{
		ResultSet result = Main.getMysql().getResult("SELECT * FROM MineLevel WHERE UUID='" + uuid + "';");
		if(result.next())
			return result != null;
		}
		catch(Exception e)
		{
			Main.debug("Errore MySql");
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * User registering method created on 04/01/2018
	 * @param uuid
	 */
	public void registerNewUser(UUID uuid)
	{
		Main.getMysql().update("INSERT INTO MineLevel (UUID, Level, Blocks) VALUES ('" + uuid + "', '1', '0');");
	}
	
	/**
	 * User level save method created on 04/01/2018
	 * When a user left his level its saved on the database
	 * @param user
	 */
	public void saveUserLevel(User user)
	{
		Main.getMysql().update("UPDATE MineLevel SET Level='" + user.getLevel() + "' WHERE UUID='" + user.getUser() + "';");
	}
	
	/**
	 * User level info method created on 04/01/2018
	 * @param uuid
	 * @return
	 */
	public int getUserLevel(UUID uuid)
	{
		try
		{
		ResultSet result = Main.getMysql().getResult("SELECT Level FROM MineLevel WHERE UUID='" + uuid + "';");
		if(result.next())
			return result.getInt("Level");
		}
		catch(Exception e)
		{
			Main.debug("Errore MySql");
			e.printStackTrace();
		}
		return -1;
	}
	
	/**
	 * User blocks save method created on 21/01/2018
	 * When a user left his breaked blocks are saved on the database
	 * @param user
	 */
	public void saveUserBlocks(User user)
	{
		Main.getMysql().update("UPDATE MineLevel SET Blocks='" + user.getBlocks() + "' WHERE UUID='" + user.getUser() + "';");
	}
	
	/**
	 * User breaked blocks info method created on 21/01/2018
	 * @param uuid
	 * @return
	 */
	public int getUserBlocks(UUID uuid)
	{
		try
		{
		ResultSet result = Main.getMysql().getResult("SELECT Blocks FROM MineLevel WHERE UUID='" + uuid + "';");
		if(result.next())
			return result.getInt("Blocks");
		}
		catch(Exception e)
		{
			Main.debug("Errore MySql");
			e.printStackTrace();
		}
		return -1;
	}
}

package me.soul.plugin.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import me.soul.plugin.Main;

public class MySql {
	
	/*
	 * This program is free software: you can redistribute it and/or modify
	 *   it under the terms of the GNU General Public License as published by
	 *   the Free Software Foundation, either version 3 of the License, or
	 *   (at your option) any later version.
	 *
	 *   This program is distributed in the hope that it will be useful,
	 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
	 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 *   GNU General Public License for more details.
	 *
	 *   You should have received a copy of the GNU General Public License
	 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
	 */
	
	private String username;
	private String password;
	private String database;
	private String host;
	private int port;
	private Connection connection;
	
	/**
	 * Set connection's info from the default config created on 02/01/2018
	 */
	public void setup()
	{
		this.setUsername(Main.getInstance().getConfig().getString("Settings.mysql.username"));
		this.setPassword(Main.getInstance().getConfig().getString("Settings.mysql.password"));
		this.setDatabase(Main.getInstance().getConfig().getString("Settings.mysql.database"));
		this.setHost(Main.getInstance().getConfig().getString("Settings.mysql.host"));
		this.setPort(Main.getInstance().getConfig().getInt("Settings.mysql.port"));
	}
	
	/**
	 * Connection method created on 02/01/2018
	 * Trying to connect to the database
	 */
	public void connect()
	{
		try
		{
			if(!this.isConnected())
			{
				this.setConnection(DriverManager.getConnection("jdbc:mysql://" + this.getHost() + ":" + this.getPort() + "/" + this.getDatabase(), this.getUsername(), this.getPassword()));
				Main.debug("Successfully connected to the database.");
			}
		}
		catch(Exception e)
		{
			Main.debug("Connection error.");
			e.printStackTrace();
		}
	}
	
	/**
	 * Connection check method created on 02/01/2018
	 * Check if the plugin is already connected to the database
	 */
	public boolean isConnected()
	{
		return this.getConnection() != null;
	}
	
	/**
	 * Table creation method created on 04/01/2018
	 * Create the database table where levels will be stored
	 */
	public void createTable()
	{
		try
		{
			 this.update("CREATE TABLE IF NOT EXISTS MineLevel (UUID VARCHAR(100), Level VARCHAR(100), Blocks VARCHAR(100));");
		}
		catch(Exception e)
		{
			Main.debug("Table error.");
			e.printStackTrace();
		}
	}
	
	/**
	 * Update method created on 04/01/2018
	 * @param query
	 */
	public void update(String query)
	{
		try
		{
			PreparedStatement statement = this.getConnection().prepareStatement(query);
		    statement.executeUpdate();
		    statement.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Result return from the database created on 04/01/2018
	 * @param qry
	 * @return
	 */
	public ResultSet getResult(String qry)
	{
		ResultSet rs = null;
		try
		{
			Statement st =  this.getConnection().createStatement();
	        rs = st.executeQuery(qry);
	    }
		catch(SQLException e)
		{
			System.err.println(e);
	    }
		return rs;
	}
	  
	/**
	 * Default connection methods created on 02/01/2018
	 * @return
	 */
	public String getUsername() 
	{
		return username;
	}
	public void setUsername(String username) 
	{
		this.username = username;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	public String getDatabase() 
	{
		return database;
	}
	public void setDatabase(String database) 
	{
		this.database = database;
	}
	public String getHost() 
	{
		return host;
	}
	public void setHost(String host) 
	{
		this.host = host;
	}
	public int getPort() 
	{
		return port;
	}
	public void setPort(int port) 
	{
		this.port = port;
	}
	public Connection getConnection() 
	{
		return connection;
	}
	public void setConnection(Connection connection) 
	{
		this.connection = connection;
	}
}

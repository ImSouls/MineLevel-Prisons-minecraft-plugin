package me.soul.plugin.utils;

import java.util.ArrayList;
import java.util.UUID;

import me.soul.plugin.User;

public class UsersUtils {

	private ArrayList<User> users = new ArrayList<User>();
	
	/**
	 * Default users utils methods created on 04/01/2018
	 * @return
	 */
	public User getUser(UUID uuid)
	{
		for(User user : this.getUsers())
		{
			if(user.getUser().equals(uuid))
				return user;
		}
		return null;
	}
	public void addUser(User user)
	{
		this.getUsers().add(user);
	}
	public void removeUser(User user)
	{
		this.getUsers().remove(user);
	}
	public ArrayList<User> getUsers()
	{
		return users;
	}
	@SuppressWarnings("unused")
	private void setUsers(ArrayList<User> users)
	{
		this.users = users;
	}
}

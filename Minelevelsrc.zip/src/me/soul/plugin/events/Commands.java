package me.soul.plugin.events;

import me.soul.plugin.Main;
import me.soul.plugin.utils.Logger;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Commands implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
	{
		if(label.equalsIgnoreCase("minelevel"))
		{
			if(!(sender instanceof Player))
			{
				return false;
			}
			Player player = (Player)sender;
			if(args.length == 0)
			{
				Logger.log(player, "�7Se hai bisogno di aiuto digita �b/minelevel help");
				Logger.log(player, "�7Custom plugin created by ImSouls_");
				return false;
			}
			if(args[0].equalsIgnoreCase("help"))
			{
				if(player.isOp())
				{
					player.sendMessage("�cAdmin�7 Help Page �8[�71�8/�71�8]");
					player.sendMessage("�7- �csetlevel <user> <level> �f-> �7Set a user level");
					player.sendMessage("�7- �csetblocks <user> <blocks> �f-> �7Set a user breaked blocks");
				}
				else
				{
					player.sendMessage("�7Help Page �8[�71�8/�71�8]");
					player.sendMessage("�7- status [user] -> Vedi le statistiche di un giocatore");
				}
			}
			if(args[0].equalsIgnoreCase("status"))
			{
				if(args.length == 2)
				{
					Player target = (Player)Bukkit.getPlayer(args[1]);
					player.sendMessage("�f�l+______________________+");
					player.sendMessage("");
					player.sendMessage("�7Statistiche di �b" + target.getName());
					player.sendMessage("");
					player.sendMessage("�7Livello: �b" + Main.getUsersUtils().getUser(target.getUniqueId()).getLevel());
					player.sendMessage("�7Totale blocchi spaccati: �b" + Main.getUsersUtils().getUser(target.getUniqueId()).getBlocks());
					player.sendMessage("�7Blocchi al prossimo livello: �b" +  (Main.getUsersUtils().getUser(target.getUniqueId()).getLevel() == 50 ? "Ultimo livello raggiunto" : Main.getUsersUtils().getUser(target.getUniqueId()).getBlocksToNextLevel()));
					player.sendMessage("");
					player.sendMessage("�f�l+______________________+");
				}
				else
				{
					player.sendMessage("�f�l+______________________+");
					player.sendMessage("");
					player.sendMessage("�7Le �btue �7statistiche");
					player.sendMessage("");
					player.sendMessage("�7Livello: �b" + Main.getUsersUtils().getUser(player.getUniqueId()).getLevel());
					player.sendMessage("�7Totale blocchi spaccati: �b" + Main.getUsersUtils().getUser(player.getUniqueId()).getBlocks());
					player.sendMessage("�7Blocchi al prossimo livello: �b" + (Main.getUsersUtils().getUser(player.getUniqueId()).getLevel() == 50 ? "Ultimo livello raggiunto" : Main.getUsersUtils().getUser(player.getUniqueId()).getBlocksToNextLevel()));
					player.sendMessage("");
					player.sendMessage("�f�l+______________________+");
				}
			}
			if(args[0].equalsIgnoreCase("setlevel"))
			{
				if(!player.isOp())
					return false;
				if(args.length < 3)
				{
					Logger.log(player, "�7Sintassi del comando errata.");
					return false;
				}
				Player target = (Player)Bukkit.getPlayer(args[1]);
				int level;
				try
				{
					level = Integer.valueOf(args[2]);
				}
				catch(Exception e)
				{
					Logger.log(player, "�7Livello invalido.");
					return false;
				}
				Main.getUsersUtils().getUser(target.getUniqueId()).setLevel(level);
				Logger.log(player, "�7Livello del giocatore �c" + target.getName() + "�7 impostato a �c" + level);
			}
			if(args[0].equalsIgnoreCase("setblocks"))
			{
				if(!player.isOp())
					return false;
				if(args.length < 3)
				{
					Logger.log(player, "�7Sintassi del comando errata.");
					return false;
				}
				Player target = (Player)Bukkit.getPlayer(args[1]);
				int blocks;
				try
				{
					blocks = Integer.valueOf(args[2]);
				}
				catch(Exception e)
				{
					Logger.log(player, "�7Numero dei blocchi invalido.");
					return false;
				}
				Main.getUsersUtils().getUser(target.getUniqueId()).setBlocks(blocks);
				Logger.log(player, "�7Numero dei blocchi spaccati del giocatore �c" + target.getName() + "�7 impostato a �c" + blocks);
			}
		}
		return false;
	}

}

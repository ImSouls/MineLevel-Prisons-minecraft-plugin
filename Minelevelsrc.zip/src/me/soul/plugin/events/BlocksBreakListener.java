package me.soul.plugin.events;

import me.soul.plugin.Main;
import me.soul.plugin.User;
import me.soul.plugin.utils.Logger;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

public class BlocksBreakListener implements Listener{

	/**
	 * Requirements check method while a player break a block created on 04/01/2018
	 * @param event
	 */
	@EventHandler
	public void onRequirementsCheck(BlockBreakEvent event)
	{
		Player player = event.getPlayer();
		User user = Main.getUsersUtils().getUser(player.getUniqueId());
		
		if(!user.canBreak(event.getBlock()) && !player.isOp())
		{
			event.setCancelled(true);
			Logger.log(player, "�7Non puoi ancora fare questa azione.");
			return;
		}
		
		Block block = event.getBlock();
		if(!(!block.getType().equals(Material.COAL_ORE) && !block.getType().equals(Material.REDSTONE_ORE) && !block.getType().equals(Material.LAPIS_ORE) && !block.getType().equals(Material.IRON_ORE) && !block.getType().equals(Material.GOLD_ORE)  && !block.getType().equals(Material.DIAMOND_ORE) && !block.getType().equals(Material.EMERALD_ORE)))
		{
			user.setBlocks(user.getBlocks() + 1);
			user.checkForLevelUp();
		}
	}
}

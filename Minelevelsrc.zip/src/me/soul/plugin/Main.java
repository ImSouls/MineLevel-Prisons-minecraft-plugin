package me.soul.plugin;

import org.bukkit.plugin.java.JavaPlugin;

import me.soul.plugin.events.BlocksBreakListener;
import me.soul.plugin.events.Commands;
import me.soul.plugin.events.JoinListener;
import me.soul.plugin.events.LeftListener;
import me.soul.plugin.events.PlayerMoveListener;
import me.soul.plugin.mysql.DatabaseManager;
import me.soul.plugin.mysql.MySql;
import me.soul.plugin.utils.UsersUtils;

public class Main extends JavaPlugin{
	
	/*
	 *   This program is free software: you can redistribute it and/or modify
	 *   it under the terms of the GNU General Public License as published by
	 *   the Free Software Foundation, either version 3 of the License, or
	 *   (at your option) any later version.
	 *
	 *   This program is distributed in the hope that it will be useful,
	 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
	 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 *   GNU General Public License for more details.
	 *
	 *   You should have received a copy of the GNU General Public License
	 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
	 *   
	 */
	
	private static Main instance;
	private static MySql mysql;
	private static DatabaseManager databaseManager;
	private static UsersUtils usersUtils;
	
	/**
	 * Main Class start method created on 02/01/2018
	 * (non-Javadoc)
	 * @see org.bukkit.plugin.java.JavaPlugin#onEnable()
	 **/
	public void onEnable()
	{
		setInstance(this);
		setMysql(new MySql());
		setDatabaseManager(new DatabaseManager());
		setUsersUtils(new UsersUtils());
		
		this.saveDefaultConfig();
		this.mysql();
		this.registerListeners();
		
		this.getCommand("minelevel").setExecutor(new Commands());
		
		debug("Successfully started MineLevel by ImSouls_");
	}
	
	/**
	 * Main Class stop method created on 02/01/2018
	 * (non-Javadoc)
	 * @see org.bukkit.plugin.java.JavaPlugin#onEnable()
	 **/
	public void onDisable()
	{
		
	}
	
	/**
	 * MySql setup created on 02/01/2018
	 */
	private void mysql()
	{
		try
		{
			getMysql().setup();
			getMysql().connect();
			getMysql().createTable();
			debug("Successfully started MySql");
		}
		catch(Exception e)
		{
			debug("MySql starting error.");
			e.printStackTrace();
		}
	}
	
	/**
	 * Print a debug message created on 02/01/2018
	 * @param message
	 */
	public static void debug(String message)
	{
		System.out.println("[Soul-Debug] " + message);
	}

	/**
	 * Listener registering method created on 04/01/2018
	 */
	private void registerListeners()
	{
		this.getServer().getPluginManager().registerEvents(new JoinListener(), this);
		this.getServer().getPluginManager().registerEvents(new LeftListener(), this);
		this.getServer().getPluginManager().registerEvents(new BlocksBreakListener(), this);
		this.getServer().getPluginManager().registerEvents(new PlayerMoveListener(), this);
	}
	
	/**
	 * Default methods created on 02/01/2018
	 * @return
	 */
	public static Main getInstance()
	{
		return instance;
	}
	public static void setInstance(Main instances)
	{
		instance = instances;
	}
	public static MySql getMysql()
	{
		return mysql;
	}
	public static void setMysql(MySql mysql)
	{
		Main.mysql = mysql;
	}
	public static DatabaseManager getDatabaseManager()
	{
		return databaseManager;
	}
	public static void setDatabaseManager(DatabaseManager databaseManager)
	{
		Main.databaseManager = databaseManager;
	}
	public static UsersUtils getUsersUtils()
	{
		return usersUtils;
	}
	public static void setUsersUtils(UsersUtils usersUtils)
	{
		Main.usersUtils = usersUtils;
	}
}

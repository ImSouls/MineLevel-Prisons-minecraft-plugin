package me.soul.plugin;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class User {
	
	private UUID user;
	private int level;
	private int blocks;
	
	/**
	 * User class created on 04/01/2018
	 * @param user
	 * @param level
	 */
	public User(UUID user, int level, int blocks)
	{
		this.setUser(user);
		this.setLevel(level);
		this.setBlocks(blocks);
	}

	/**
	 * Check for the requirements to break the block created on 04/01/2018
	 * @param block
	 * @return
	 */
	public boolean canBreak(Block block)
	{
		if(!block.getType().equals(Material.COAL_ORE) && !block.getType().equals(Material.REDSTONE_ORE) && !block.getType().equals(Material.LAPIS_ORE) && !block.getType().equals(Material.IRON_ORE) && !block.getType().equals(Material.GOLD_ORE)  && !block.getType().equals(Material.DIAMOND_ORE) && !block.getType().equals(Material.EMERALD_ORE))
			return true;
		if(this.getLevel() < 5)
		{
			if(!this.hasPickaxeEquipped())
				if(block.getType().equals(Material.COAL_ORE))
					return true;
		}
		if(this.getLevel() < 10)
		{
			if(this.hasPickaxeEquipped() && this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) && block.getType().equals(Material.COAL_ORE))
					return true;
			else
				if(!this.hasPickaxeEquipped() && block.getType().equals(Material.COAL_ORE))
					return true;
				else
					return false;
		}
		if(this.getLevel() < 15)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 20)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 25)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 30)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.IRON_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 35)
		{
			if(this.hasPickaxeEquipped() && (this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE) || this.getPlayer().getItemInHand().getType().equals(Material.IRON_PICKAXE)) && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE)))
			{
					return true;
			}
			else
			{
				if(!this.hasPickaxeEquipped() && (block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE)))
					return true;
				else
					return false;
			}
		}
		if(this.getLevel() < 40)
		{
			if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE))
				return true;
			else
				return false;
		}
		if(this.getLevel() < 45)
		{
			if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE) || block.getType().equals(Material.GOLD_ORE))
				return true;
			else
				return false;
		}
		if(this.getLevel() < 50)
		{
			if(block.getType().equals(Material.COAL_ORE) || block.getType().equals(Material.REDSTONE_ORE) || block.getType().equals(Material.LAPIS_ORE) || block.getType().equals(Material.IRON_ORE) || block.getType().equals(Material.GOLD_ORE)  || block.getType().equals(Material.DIAMOND_ORE))
				return true;
			else
				return false;
		}
		if(this.getLevel() >= 50)
			return true;
		return false;
	}
	
	@SuppressWarnings("deprecation")
	public void checkForLevelUp()
	{
		switch(this.getBlocks())
		{
		case 100:
			this.setLevel(2);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 300:
			this.setLevel(3);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 500:
			this.setLevel(4);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 1000:
			this.setLevel(5);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 1300:
			this.setLevel(6);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 1600:
			this.setLevel(7);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 1900:
			this.setLevel(8);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 2200:
			this.setLevel(9);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 2700:
			this.setLevel(10);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 3200:
			this.setLevel(11);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 3700:
			this.setLevel(12);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 4200:
			this.setLevel(13);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 4700:
			this.setLevel(14);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 5700:
			this.setLevel(15);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 6200:
			this.setLevel(16);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 6700:
			this.setLevel(17);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 7200:
			this.setLevel(18);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 7700:
			this.setLevel(19);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 8700:
			this.setLevel(20);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 9200:
			this.setLevel(21);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 9700:
			this.setLevel(22);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 10200:
			this.setLevel(23);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 10700:
			this.setLevel(24);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 12700:
			this.setLevel(25);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 13200:
			this.setLevel(26);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 13700:
			this.setLevel(27);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 14200:
			this.setLevel(28);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 14700:
			this.setLevel(29);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 16700:
			this.setLevel(30);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 17200:
			this.setLevel(31);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 17700:
			this.setLevel(32);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 18200:
			this.setLevel(33);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 18700:
			this.setLevel(34);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 21700:
			this.setLevel(35);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 22200:
			this.setLevel(36);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 22700:
			this.setLevel(37);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 33200:
			this.setLevel(38);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 33700:
			this.setLevel(39);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 37700:
			this.setLevel(40);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 38200:
			this.setLevel(41);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 38700:
			this.setLevel(42);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 39200:
			this.setLevel(43);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 39700:
			this.setLevel(44);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 44700:
			this.setLevel(45);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 45200:
			this.setLevel(46);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 45700:
			this.setLevel(47);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 46200:
			this.setLevel(48);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 46700:
			this.setLevel(49);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		case 56700:
			this.setLevel(50);
			this.getPlayer().sendTitle("�3�lL�bivello", "�7Hai raggiunto il livello �b" + this.getLevel() +"�7!");
			Bukkit.broadcastMessage("�6�lM�eine�3�lL�bevel �8� �6" + this.getPlayer().getName() + "�7 ha raggiunto il livello �b" + this.getLevel() +"�7!");
			break;
		}
	}
	
	public boolean hasPickaxeEquipped()
	{
		return this.getPlayer().getItemInHand() != null &&
				(this.getPlayer().getItemInHand().getType().equals(Material.WOOD_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.STONE_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.IRON_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.GOLD_PICKAXE) ||
				this.getPlayer().getItemInHand().getType().equals(Material.DIAMOND_PICKAXE));
	}
	
	public Player getPlayer()
	{
		return Bukkit.getPlayer(this.getUser());
	}
	public UUID getUser()
	{
		return user;
	}
	public void setUser(UUID user)
	{
		this.user = user;
	}
	public int getLevel()
	{
		return level;
	}
	public void setLevel(int level)
	{
		this.level = level;
	}

	public int getBlocks() {
		return blocks;
	}

	public void setBlocks(int blocks) {
		this.blocks = blocks;
	}
}
